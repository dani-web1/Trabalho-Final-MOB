# ClimaCapivariApp

### API Utilizada
- **HG Brasil Weather**
- Link da Documentação: https://hgbrasil.com/status/weather

### Como rodar o projeto
Para executar o aplicativo em sua máquina, é necessário configurar a chave da API.
1. Abra o arquivo local.properties na raiz do projeto.
2. Adicione a seguinte linha ao final do arquivo:
   WEATHER_API_KEY="69f382df"
3. Sincronize o Gradle (Sync Project with Gradle Files).
4. Execute o app no emulador ou dispositivo físico.

### Onde encontrar os requisitos da disciplina:
- **ConstraintLayout:** Utilizado na activity_main.xml e activity_historico.xml.
- **SplashScreen:** Implementada na classe SplashActivity.java.
- **Intent:** Navegação feita no clique do botão "Ver Histórico" na MainActivity.java.
- **SQLite (DAO):** Implementado no arquivo ClimaDAO.java e ClimaDbHelper.java (Criar, listar, excluir).
- **Retrofit/Gson:** Interface WeatherApiService.java e classe modelo WeatherResponse.java.
- **Glide:** Utilizado na MainActivity.java para carregar o ícone de clima na tela.
- **Segurança:** Chave isolada em local.properties lida pelo BuildConfig na MainActivity.java.