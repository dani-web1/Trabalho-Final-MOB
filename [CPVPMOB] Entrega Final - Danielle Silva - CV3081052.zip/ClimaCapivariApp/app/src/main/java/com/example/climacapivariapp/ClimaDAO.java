package com.example.climacapivariapp;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;
public class ClimaDAO {
    private SQLiteDatabase db;
    private DatabaseHelper dbHelper;

    public ClimaDAO(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() {
        db = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public long inserir(String localidade, String temperatura) {
        ContentValues values = new ContentValues();
        values.put("localidade", localidade);
        values.put("temperatura", temperatura);
        return db.insert("historico", null, values);
    }

    public List<ClimaHistorico> listarTodos() {
        List<ClimaHistorico> lista = new ArrayList<>();
        Cursor cursor = db.query("historico", null, null, null, null, null, "id DESC");

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String loc = cursor.getString(cursor.getColumnIndexOrThrow("localidade"));
                String temp = cursor.getString(cursor.getColumnIndexOrThrow("temperatura"));
                lista.add(new ClimaHistorico(id, loc, temp));
            } while (cursor.moveToNext());
            cursor.close();
        }
        return lista;
    }

    public void excluir(int id) {
        db.delete("historico", "id = ?", new String[]{String.valueOf(id)});
    }
}
