package com.example.climacapivariapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    private EditText etBuscarCidade;
    private Button btnBuscar, btnSalvarHistorico, btnVerHistorico;
    private TextView tvCidade, tvTemperatura, tvCondicao, tvStatusDb;
    private ImageView ivIconeClima;
    private ClimaDAO climaDAO;
    private String localidadeAtual = "";
    private String tempAtual = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etBuscarCidade = findViewById(R.id.etBuscarCidade);
        btnBuscar = findViewById(R.id.btnBuscar);
        tvCidade = findViewById(R.id.tvCidade);
        tvTemperatura = findViewById(R.id.tvTemperatura);
        tvCondicao = findViewById(R.id.tvCondicao);
        tvStatusDb = findViewById(R.id.tvStatusDb);
        btnSalvarHistorico = findViewById(R.id.btnSalvarHistorico);
        btnVerHistorico = findViewById(R.id.btnVerHistorico);

        ivIconeClima = findViewById(R.id.ivIconeClima);

        climaDAO = new ClimaDAO(this);
        climaDAO.open();
        atualizarContadorBanco();

        btnBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String cidadeDigitada = etBuscarCidade.getText().toString().trim();
                if (!cidadeDigitada.isEmpty()) {
                    buscarDadosClima(cidadeDigitada);
                } else {
                    Toast.makeText(MainActivity.this, "Digite o nome de uma cidade!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnSalvarHistorico.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!localidadeAtual.isEmpty()) {
                    climaDAO.inserir(localidadeAtual, tempAtual);
                    Toast.makeText(MainActivity.this, "Salvo com sucesso!", Toast.LENGTH_SHORT).show();
                    atualizarContadorBanco();
                } else {
                    Toast.makeText(MainActivity.this, "Pesquise uma cidade primeiro!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnVerHistorico.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, HistoricoActivity.class);
                startActivity(intent);
            }
        });
    }

    private void buscarDadosClima(String cidade) {
        tvCidade.setText("Carregando...");

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.hgbrasil.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        WeatherApiService apiService = retrofit.create(WeatherApiService.class);

        String apiKey = "69f382df";

        Call<WeatherResponse> call = apiService.getWeatherByCity(apiKey, cidade);

        call.enqueue(new Callback<WeatherResponse>() {
            @Override
            public void onResponse(Call<WeatherResponse> call, Response<WeatherResponse> response) {
                if (response.isSuccessful() && response.body() != null && response.body().getResults() != null) {
                    WeatherResponse.Results dados = response.body().getResults();

                    localidadeAtual = dados.getCity();
                    tempAtual = dados.getTemp() + " °C";

                    tvCidade.setText(localidadeAtual);
                    tvTemperatura.setText(tempAtual);
                    tvCondicao.setText("Condição: " + dados.getDescription());

                    String urlImagem = "https://cdn-icons-png.flaticon.com/512/1163/1163661.png";
                    Glide.with(MainActivity.this)
                            .load(urlImagem)
                            .into(ivIconeClima);

                } else {
                    tvCidade.setText("Cidade não encontrada.");
                }
            }

            @Override
            public void onFailure(Call<WeatherResponse> call, Throwable t) {
                tvCidade.setText("Falha de Rede: " + t.getMessage());
            }
        });
    }

    private void atualizarContadorBanco() {
        List<ClimaHistorico> lista = climaDAO.listarTodos();
        tvStatusDb.setText("Itens salvos no banco local: " + lista.size());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        climaDAO.close();
    }
}