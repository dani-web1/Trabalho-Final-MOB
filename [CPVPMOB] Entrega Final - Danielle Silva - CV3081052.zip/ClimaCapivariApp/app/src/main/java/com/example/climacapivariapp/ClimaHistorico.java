package com.example.climacapivariapp;

public class ClimaHistorico {
    private int id;
    private String localidade;
    private String temperatura;

    public ClimaHistorico(int id, String localidade, String temperatura) {
        this.id = id;
        this.localidade = localidade;
        this.temperatura = temperatura;
    }

    public int getId() { return id; }
    public String getLocalidade() { return localidade; }
    public String getTemperatura() { return temperatura; }
}
