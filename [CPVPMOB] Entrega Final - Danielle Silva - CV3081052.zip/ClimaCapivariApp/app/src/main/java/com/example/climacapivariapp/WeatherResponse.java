package com.example.climacapivariapp;

public class WeatherResponse {
    private Results results;

    public Results getResults() {
        return results;
    }

    public static class Results {
        private int temp;
        private String city;
        private String description;

        public int getTemp() {
            return temp;
        }

        public String getCity() {
            return city;
        }

        public String getDescription() {
            return description;
        }
    }
}