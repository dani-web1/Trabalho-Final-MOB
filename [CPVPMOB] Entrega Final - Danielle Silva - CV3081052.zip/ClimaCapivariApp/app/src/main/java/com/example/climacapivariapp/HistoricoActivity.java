package com.example.climacapivariapp;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class HistoricoActivity extends AppCompatActivity {
    private LinearLayout containerHistorico;
    private ClimaDAO climaDAO;
    private Button btnVoltar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historico);

        containerHistorico = findViewById(R.id.containerHistorico);
        btnVoltar = findViewById(R.id.btnVoltar);

        climaDAO = new ClimaDAO(this);
        climaDAO.open();

        carregarLista();

        // 3. Ação do botão voltar
        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void carregarLista() {
        containerHistorico.removeAllViews();
        List<ClimaHistorico> lista = climaDAO.listarTodos();

        if (lista.isEmpty()) {
            TextView tvVazio = new TextView(this);
            tvVazio.setText("Nenhum histórico salvo.");
            tvVazio.setTextColor(Color.BLACK);
            containerHistorico.addView(tvVazio);
            return;
        }

        for (final ClimaHistorico item : lista) {
            LinearLayout itemLayout = new LinearLayout(this);
            itemLayout.setOrientation(LinearLayout.HORIZONTAL);
            itemLayout.setPadding(0, 0, 0, 24);

            TextView tvDados = new TextView(this);
            tvDados.setText(item.getLocalidade() + " - " + item.getTemperatura());
            tvDados.setTextColor(Color.parseColor("#0D47A1"));
            tvDados.setTextSize(16f);
            tvDados.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

            Button btnExcluir = new Button(this);
            btnExcluir.setText("Excluir");
            btnExcluir.setBackgroundColor(Color.parseColor("#42A5F5"));
            btnExcluir.setTextColor(Color.WHITE);

            btnExcluir.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    climaDAO.excluir(item.getId());
                    Toast.makeText(HistoricoActivity.this, "Item excluído", Toast.LENGTH_SHORT).show();
                    carregarLista();
                }
            });

            itemLayout.addView(tvDados);
            itemLayout.addView(btnExcluir);
            containerHistorico.addView(itemLayout);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        climaDAO.close();
    }
}